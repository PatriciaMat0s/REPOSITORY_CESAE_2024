package Domain.Enums;

    public enum TipoCarro {

        F1, RALLY, GT, CARROCA
    }
